# Champion Perfumes — Complete Store

## Admin
Open `/admin` after deployment and enter `ADMIN_PASSWORD`.

You can:
- Add perfumes
- Edit perfumes
- Delete perfumes
- Set price, stock, concentration, notes and description
- See orders
- See basic order/revenue totals

## Setup
1. Create a Supabase project.
2. Run `supabase.sql`.
3. Copy `.env.example` to `.env.local`.
4. Fill in the Supabase URL, anon key, service-role key and admin password.
5. `npm install`
6. `npm run dev`

## Security
The admin key approach is a starter implementation. For a production store, replace it with Supabase Auth/session-based authentication and keep the service-role key server-only.
